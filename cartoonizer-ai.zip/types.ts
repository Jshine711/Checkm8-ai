
export interface AppState {
  uploadedImage: File | null;
  uploadedImagePreview: string | null;
  aspectRatio: string;
  numImages: number;
  extraPrompt: string;
  generatedImages: string[];
  isLoading: boolean;
  error: string | null;
}
