import React, { useState, useEffect } from 'react';
import { PlusIcon, SaveIcon, TrashIcon } from './Icons';
import Tooltip from './Tooltip';

interface PromptManagerProps {
  extraPrompt: string;
  setExtraPrompt: (prompt: string) => void;
  disabled: boolean;
  onPromptSelectAndGenerate: (prompt: string) => void;
}

const suggestionPrompts = [
  'Vintage comic book style',
  'Pixar movie character',
  'Anime key visual',
  'Detailed vector art',
  'Ghibli style background',
  '80s cartoon aesthetic',
];

const PromptManager: React.FC<PromptManagerProps> = ({ extraPrompt, setExtraPrompt, disabled, onPromptSelectAndGenerate }) => {
  const [favoritePrompts, setFavoritePrompts] = useState<string[]>([]);

  useEffect(() => {
    try {
      const storedFavorites = localStorage.getItem('favoritePrompts');
      if (storedFavorites) {
        setFavoritePrompts(JSON.parse(storedFavorites));
      }
    } catch (error) {
      console.error("Failed to load favorite prompts from localStorage", error);
    }
  }, []);

  useEffect(() => {
    try {
        localStorage.setItem('favoritePrompts', JSON.stringify(favoritePrompts));
    } catch (error) {
        console.error("Failed to save favorite prompts to localStorage", error);
    }
  }, [favoritePrompts]);


  const handleSaveFavorite = () => {
    if (extraPrompt && !favoritePrompts.includes(extraPrompt)) {
      setFavoritePrompts(prev => [extraPrompt, ...prev].slice(0, 10)); // Limit to 10 favorites
    }
  };

  const handleRemoveFavorite = (promptToRemove: string) => {
    setFavoritePrompts(prev => prev.filter(p => p !== promptToRemove));
  };
  
  const handleSuggestionClick = (prompt: string) => {
    const newPrompt = extraPrompt ? `${extraPrompt}, ${prompt}` : prompt;
    onPromptSelectAndGenerate(newPrompt);
  };

  const handleFavoriteClick = (prompt: string) => {
    onPromptSelectAndGenerate(prompt);
  };

  return (
    <div className="space-y-4">
      <div>
        <label htmlFor="extra-prompt" className="block text-sm font-medium text-gray-300 mb-2">Add extra detail</label>
        <div className="relative">
          <textarea
            id="extra-prompt"
            rows={3}
            value={extraPrompt}
            onChange={(e) => setExtraPrompt(e.target.value)}
            disabled={disabled}
            className="w-full bg-gray-700 text-gray-200 rounded-md p-2 pr-10 border border-transparent focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition disabled:opacity-50"
            placeholder="e.g., cel-shading, vibrant colors..."
          />
          <Tooltip text="Save prompt">
            <button
              onClick={handleSaveFavorite}
              disabled={disabled || !extraPrompt || favoritePrompts.includes(extraPrompt)}
              className="absolute top-2 right-2 p-1.5 text-gray-400 rounded-full hover:bg-gray-600 hover:text-white transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <SaveIcon />
            </button>
          </Tooltip>
        </div>
      </div>
      
      <div>
        <h3 className="text-sm font-medium text-gray-400 mb-2">Suggestions</h3>
        <div className="flex flex-wrap gap-2">
          {suggestionPrompts.map(prompt => (
            <button
              key={prompt}
              onClick={() => handleSuggestionClick(prompt)}
              disabled={disabled}
              className="flex items-center gap-1.5 bg-gray-700 hover:bg-gray-600 text-gray-300 text-xs font-medium px-2 py-1 rounded-full transition-colors disabled:opacity-50"
            >
              <PlusIcon />
              {prompt}
            </button>
          ))}
        </div>
      </div>
      
      {favoritePrompts.length > 0 && (
        <div>
          <h3 className="text-sm font-medium text-gray-400 mb-2">Favorites</h3>
          <div className="flex flex-wrap gap-2">
            {favoritePrompts.map(prompt => (
              <div key={prompt} className="group relative bg-indigo-900/50 text-indigo-300 text-xs font-medium pl-2 pr-1 py-1 rounded-full flex items-center">
                <span className="cursor-pointer" onClick={() => !disabled && handleFavoriteClick(prompt)}>{prompt}</span>
                <Tooltip text="Remove">
                    <button
                        onClick={() => handleRemoveFavorite(prompt)}
                        disabled={disabled}
                        className="ml-1.5 p-0.5 rounded-full text-indigo-400 opacity-0 group-hover:opacity-100 hover:bg-indigo-700/50 hover:text-white transition-opacity"
                    >
                        <TrashIcon />
                    </button>
                </Tooltip>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default PromptManager;