import React from 'react';
import { AppState } from '../types';
import ImageUploader from './ImageUploader';
import PromptManager from './PromptManager';
import { GenerateIcon } from './Icons';

interface ControlPanelProps {
  appState: AppState;
  setAppState: React.Dispatch<React.SetStateAction<AppState>>;
  onGenerateClick: (promptOverride?: string) => void;
}

const aspectRatios = ['1:1', '4:3', '3:4', '16:9', '9:16'];

const ControlPanel: React.FC<ControlPanelProps> = ({ appState, setAppState, onGenerateClick }) => {
  const { isLoading, uploadedImage, aspectRatio, numImages, extraPrompt } = appState;

  const handleImageUpload = (file: File | null) => {
    if (file) {
      setAppState(prev => ({
        ...prev,
        uploadedImage: file,
        uploadedImagePreview: URL.createObjectURL(file),
      }));
    } else {
      setAppState(prev => ({
        ...prev,
        uploadedImage: null,
        uploadedImagePreview: null,
      }));
    }
  };

  const setExtraPrompt = (prompt: string) => {
    setAppState(prev => ({ ...prev, extraPrompt: prompt }));
  };
  
  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-5 space-y-6 sticky top-6">
      <ImageUploader onImageUpload={handleImageUpload} previewUrl={appState.uploadedImagePreview} disabled={isLoading} />
      
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">Aspect Ratio</label>
        <div className="grid grid-cols-5 gap-2">
          {aspectRatios.map(ratio => (
            <button
              key={ratio}
              onClick={() => setAppState(prev => ({...prev, aspectRatio: ratio}))}
              disabled={isLoading}
              className={`px-2 py-1.5 text-xs font-semibold rounded-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500 ${
                aspectRatio === ratio ? 'bg-indigo-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {ratio}
            </button>
          ))}
        </div>
      </div>
      
      <div>
        <label htmlFor="num-images" className="block text-sm font-medium text-gray-300 mb-2">Number of Images ({numImages})</label>
        <input
          id="num-images"
          type="range"
          min="1"
          max="4"
          value={numImages}
          onChange={(e) => setAppState(prev => ({ ...prev, numImages: parseInt(e.target.value, 10) }))}
          disabled={isLoading}
          className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer disabled:cursor-not-allowed accent-indigo-500"
        />
      </div>

      <PromptManager 
        extraPrompt={extraPrompt}
        setExtraPrompt={setExtraPrompt}
        disabled={isLoading}
        onPromptSelectAndGenerate={onGenerateClick}
      />
      
      <button
        onClick={() => onGenerateClick()}
        disabled={isLoading || !uploadedImage}
        className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:from-gray-600 disabled:to-gray-700"
      >
        <GenerateIcon />
        {isLoading ? 'Generating...' : 'Cartoonize!'}
      </button>
    </div>
  );
};

export default ControlPanel;