
import React from 'react';
import { DownloadIcon, ImageIcon } from './Icons';

interface ResultsDisplayProps {
  isLoading: boolean;
  generatedImages: string[];
  error: string | null;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ isLoading, generatedImages, error }) => {
  const handleDownload = (base64Image: string, index: number) => {
    const link = document.createElement('a');
    link.href = base64Image;
    link.download = `cartoon_image_${index + 1}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const LoadingSkeleton = () => (
    <div className="bg-gray-800 rounded-lg p-4 animate-pulse">
      <div className="w-full h-64 bg-gray-700 rounded-md"></div>
    </div>
  );

  const Placeholder = () => (
    <div className="flex flex-col items-center justify-center h-full text-center text-gray-500">
      <ImageIcon />
      <h3 className="mt-4 text-xl font-semibold text-gray-400">Your cartoon creations will appear here</h3>
      <p className="mt-1">Upload an image and adjust the settings to get started.</p>
    </div>
  );

  const ErrorDisplay = ({ message }: { message: string }) => (
    <div className="flex items-center justify-center h-full text-center">
        <div className="bg-red-900/20 border border-red-500/30 text-red-300 p-4 rounded-lg">
            <h3 className="font-bold">An Error Occurred</h3>
            <p className="text-sm">{message}</p>
        </div>
    </div>
  );

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-5 min-h-[calc(100vh-180px)] flex flex-col">
      {isLoading && (
        <div className={`grid gap-4 grid-cols-1 ${generatedImages.length > 1 ? 'md:grid-cols-2' : ''}`}>
          {Array(generatedImages.length || 1).fill(0).map((_, i) => <LoadingSkeleton key={i} />)}
        </div>
      )}
      {!isLoading && error && <ErrorDisplay message={error} />}
      {!isLoading && !error && generatedImages.length > 0 && (
        <div className={`grid gap-4 grid-cols-1 ${generatedImages.length > 1 ? 'md:grid-cols-2' : ''}`}>
          {generatedImages.map((image, index) => (
            <div key={index} className="group relative rounded-lg overflow-hidden border-2 border-transparent hover:border-indigo-500 transition-all">
              <img src={image} alt={`Generated cartoon ${index + 1}`} className="w-full h-auto object-cover" />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <button
                  onClick={() => handleDownload(image, index)}
                  className="flex items-center gap-2 bg-white/10 backdrop-blur-md text-white font-bold py-2 px-4 rounded-lg hover:bg-white/20 transition-colors"
                >
                  <DownloadIcon />
                  Download
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      {!isLoading && !error && generatedImages.length === 0 && <Placeholder />}
    </div>
  );
};

export default ResultsDisplay;
