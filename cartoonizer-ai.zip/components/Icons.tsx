
import React from 'react';

export const UploadIcon: React.FC = () => (
  <svg className="w-8 h-8 mb-4 text-gray-500" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 16">
    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2" />
  </svg>
);

export const XIcon: React.FC = () => (
  <svg className="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
  </svg>
);

export const GenerateIcon: React.FC = () => (
    <svg className="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12.0006 18.26L4.92959 21.0706L6.92359 13.0616L0.552582 7.96959L8.65559 7.41959L12.0006 0L15.3456 7.41959L23.4486 7.96959L17.0776 13.0616L19.0716 21.0706L12.0006 18.26Z"></path></svg>
);

export const PlusIcon: React.FC = () => (
    <svg className="w-3 h-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M11 11V5H13V11H19V13H13V19H11V13H5V11H11Z"></path></svg>
);

export const SaveIcon: React.FC = () => (
    <svg className="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M7 19V13H17V19H19V7.82843L16.1716 5H5V19H7ZM4 3H17L21 7V20C21 20.5523 20.5523 21 20 21H4C3.44772 21 3 20.5523 3 20V4C3 3.44772 3.44772 3 4 3ZM9 15V19H15V15H9Z"></path></svg>
);

export const TrashIcon: React.FC = () => (
    <svg className="w-3 h-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M17 6H22V8H20V21C20 21.5523 19.5523 22 19 22H5C4.44772 22 4 21.5523 4 21V8H2V6H7V3C7 2.44772 7.44772 2 8 2H16C16.5523 2 17 2.44772 17 3V6ZM18 8H6V20H18V8ZM9 11H11V17H9V11ZM13 11H15V17H13V11ZM9 4V6H15V4H9Z"></path></svg>
);

export const DownloadIcon: React.FC = () => (
    <svg className="w-5 h-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M13 10H18L12 16L6 10H11V3H13V10ZM4 18H20V20H4V18Z"></path></svg>
);

export const ImageIcon: React.FC = () => (
    <svg className="w-16 h-16 text-gray-700" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M4.82843 3H19.1716C20.1912 3 21.0195 3.37624 21.6669 4.00845L21.7071 4.04961C22.2857 4.70868 22.6001 5.5623 22.5493 6.4504L22.5356 6.64286V19.1716C22.5356 20.1912 21.7073 21.0195 21.0597 21.6669L21.0195 21.7071C20.3605 22.2857 19.5068 22.6001 18.6187 22.5493L18.4263 22.5356H4.82843C3.80883 22.5356 2.98056 22.1593 2.33315 21.5271L2.29289 21.486C1.71431 20.8269 1.39994 19.9733 1.45071 19.0852L1.46443 18.8927V4.82843C1.46443 3.80883 2.2927 2.98056 2.94029 2.33315L2.98056 2.29289C3.63962 1.71431 4.49325 1.39994 5.38131 1.45071L5.57372 1.46443H18.8927C19.8693 1.46443 20.7297 1.81504 21.3663 2.4284L18.8927 1.46443H5.57372C4.55412 1.46443 3.72585 1.84068 3.07844 2.47289L3.03818 2.51405C2.4596 3.17311 2.14523 4.02674 2.196 4.9148L2.20972 5.10721V18.8927C2.20972 19.9123 3.03799 20.7406 4.0856 21.388L4.12586 21.4292C4.70444 22.0882 5.55806 22.4026 6.44612 22.3518L6.63853 22.3381H18.4263C19.4459 22.3381 20.2741 21.9619 20.9216 21.3297L20.9618 21.2885C21.5404 20.6295 21.8548 19.7758 21.804 18.8878L21.7903 18.6953V6.64286C21.7903 5.62325 20.962 4.79499 20.0144 4.14758L19.9742 4.10642C19.3151 3.52784 18.4615 3.21347 17.5734 3.26424L17.381 3.27796H4.82843V3ZM14.5 10C15.8807 10 17 11.1193 17 12.5C17 13.8807 15.8807 15 14.5 15C13.1193 15 12 13.8807 12 12.5C12 11.1193 13.1193 10 14.5 10ZM5.5 18L9.5 12L12.0642 15.3116C12.4463 15.8202 13.1931 15.9328 13.7017 15.5507L13.8116 15.4607L19.5 8L20.5 18H5.5Z"></path></svg>
);
