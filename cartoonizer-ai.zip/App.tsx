import React, { useState, useCallback } from 'react';
import ControlPanel from './components/ControlPanel';
import ResultsDisplay from './components/ResultsDisplay';
import { cartoonizeImage, fileToBase64 } from './services/geminiService';
import { AppState } from './types';

function App() {
  const [appState, setAppState] = useState<AppState>({
    uploadedImage: null,
    uploadedImagePreview: null,
    aspectRatio: '1:1',
    numImages: 1,
    extraPrompt: '',
    generatedImages: [],
    isLoading: false,
    error: null,
  });

  const handleGenerateClick = useCallback(async (promptOverride?: string) => {
    if (!appState.uploadedImage) {
      setAppState(prev => ({ ...prev, error: 'Please upload an image first.' }));
      return;
    }

    const promptToUse = promptOverride !== undefined ? promptOverride : appState.extraPrompt;

    setAppState(prev => ({ 
      ...prev, 
      isLoading: true, 
      error: null, 
      generatedImages: [],
      extraPrompt: promptToUse,
    }));

    try {
      const { file, mimeType } = await fileToBase64(appState.uploadedImage);
      const mainPrompt = `Apply a high quality, hyper realistic cartoon effect to this image. The final image should have an aspect ratio of ${appState.aspectRatio}.`;
      const fullPrompt = `${mainPrompt} ${promptToUse}`.trim();

      const promises = Array(appState.numImages).fill(0).map(() => 
        cartoonizeImage(file, mimeType, fullPrompt)
      );

      const results = await Promise.all(promises);
      setAppState(prev => ({ ...prev, generatedImages: results, isLoading: false }));
    } catch (err) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setAppState(prev => ({ ...prev, error: `Failed to generate images: ${errorMessage}`, isLoading: false }));
    }
  }, [appState.uploadedImage, appState.aspectRatio, appState.extraPrompt, appState.numImages]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center p-4 selection:bg-indigo-500 selection:text-white">
      <header className="w-full max-w-7xl text-center py-6">
        <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-indigo-500">
          Cartoonizer AI
        </h1>
        <p className="text-gray-400 mt-2">Transform your photos into stunning, hyper-realistic cartoons.</p>
      </header>
      <main className="w-full max-w-7xl flex-grow grid grid-cols-1 lg:grid-cols-12 gap-8 mt-4">
        <div className="lg:col-span-4 xl:col-span-3">
          <ControlPanel 
            appState={appState}
            setAppState={setAppState}
            onGenerateClick={handleGenerateClick}
          />
        </div>
        <div className="lg:col-span-8 xl:col-span-9">
          <ResultsDisplay 
            isLoading={appState.isLoading}
            generatedImages={appState.generatedImages}
            error={appState.error}
          />
        </div>
      </main>
    </div>
  );
}

export default App;